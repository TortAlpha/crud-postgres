﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8
{
    public partial class ChooseForm : Form
    {
        public delegate void SelectedRowHandler(string chosen_id, DataGridViewCellEventArgs e);
        public event SelectedRowHandler OnRowSelected;
        public DataGridViewCellEventArgs src_e;

        public ChooseForm(string tableName, DataGridViewCellEventArgs src_e)
        {
            InitializeComponent();
            this.src_e = src_e;
            PostgresModule.setGridView(PostgresModule.getDataTable(tableName), dataGridView1);
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToDeleteRows = false;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
            Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    string chosen_id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    OnRowSelected?.Invoke(chosen_id, src_e);
                    Close();
                    Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
