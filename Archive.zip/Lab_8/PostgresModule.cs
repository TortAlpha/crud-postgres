﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using Npgsql;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lab_8
{
    class PostgresModule
    {
        public static NpgsqlConnection _connection = null;

        public static void OpenConnection(string host, string port, string user, string pass, string db)
        {
            if (_connection != null)
            {
                if (_connection.State == System.Data.ConnectionState.Open) _connection.Close();
                _connection.Dispose();
            }
            _connection = new NpgsqlConnection(@"Server=" + host + ";Port=" + port + ";User Id=" + user + ";Password=" + pass + ";DataBase=" + db);
            _connection.Open();
            if (_connection.State == System.Data.ConnectionState.Open) MessageBox.Show("Connected!");
            else MessageBox.Show("Not connected!");


        }

        public static bool getConnectionStatus()
        {
            try
            {
                if (_connection != null)
                {
                    return _connection.State == System.Data.ConnectionState.Open;
                }
                throw new Exception("No connection!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public static DataTable? getSqlComResult(string sql_com)
        {
            DataTable dataTable = new DataTable();
            try
            {
                using (NpgsqlCommand command = _connection.CreateCommand())
                {
                    command.CommandText = sql_com;

                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        dataTable.Load(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }

            return dataTable;
        }

        public static DataTable? getDataTable(string tableName)
        {
            try
            {
                string sql_com = "SELECT * FROM public." + tableName;
                return getSqlComResult(sql_com);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error!\n" + ex.Message);
                return null;
            }
        }

        public static DataTable? getDataTable(string tableName, string condtition)
        {
            try
            {
                string sql_com = "SELECT * FROM public." + tableName + condtition;
                return getSqlComResult(sql_com);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error!\n" + ex.Message);
                return null;
            }
        }

        public static void DeleteRows(DataGridView dataGridView, string table)
        {
            try
            {
                NpgsqlCommand com = _connection.CreateCommand();

                foreach (DataGridViewRow row in dataGridView.SelectedRows)
                {
                    var id = row.Cells[0].Value;
                    var id_col_name = dataGridView.Columns[0].Name;
                    com.CommandText = $"DELETE FROM {table} WHERE {id_col_name} = {id}";
                    com.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error!\n" + ex.Message);
            }
        }

        public static void InsertRowsWithID(DataGridView dataGridView, string table)
        {
            try
            {
                DataTable Table_template = getDataTable(table, " LIMIT 0");
                string sql_com = $"INSERT INTO {table} (";
                string valuesClause = "VALUES (";

                List<string> columnNames = new List<string>();

                foreach (DataColumn el in Table_template.Columns)
                {
                    sql_com += (sql_com.EndsWith("(") ? "" : ", ") + el.ColumnName;
                    valuesClause += (valuesClause.EndsWith("(") ? "" : ", ") + "@" + el.ColumnName;
                    columnNames.Add(el.ColumnName);
                }
                sql_com += ") " + valuesClause + ")";

                using (NpgsqlCommand command = _connection.CreateCommand())
                {
                    command.CommandText = sql_com;

                    for (int i = 0; i < columnNames.Count; ++i)
                    {
                        var value = dataGridView.Rows[0].Cells[i].Value;
                        command.Parameters.AddWithValue("@" + columnNames[i], value ?? DBNull.Value);
                    }

                    int res = command.ExecuteNonQuery();
                    if (res > -1) MessageBox.Show("Запись успешно добавлена");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления записи: " + ex.Message);
            }
        }

        public static void InsertRows(DataGridView dataGridView, string table)
        {
            try
            {
                DataTable Table_template = getDataTable(table, " LIMIT 0");
                string sql_com = $"INSERT INTO {table} (";
                string valuesClause = "VALUES (";

                bool first = true;
                List<string> columnNames = new List<string>();

                foreach (DataColumn el in Table_template.Columns)
                {
                    if (first)
                    {
                        first = false; // Пропускаем первый столбец, так как предполагается, что он serial типа
                        continue;
                    }
                    sql_com += (sql_com.EndsWith("(") ? "" : ", ") + el.ColumnName;
                    valuesClause += (valuesClause.EndsWith("(") ? "" : ", ") + "@" + el.ColumnName;
                    columnNames.Add(el.ColumnName); 
                }
                sql_com += ") " + valuesClause + ")";

                using (NpgsqlCommand command = _connection.CreateCommand())
                {
                    command.CommandText = sql_com;

                    for (int i = 0; i < columnNames.Count; ++i)
                    {
                        var value = dataGridView.Rows[0].Cells[i + 1].Value;
                        command.Parameters.AddWithValue("@" + columnNames[i], value ?? DBNull.Value);
                    }

                    int res = command.ExecuteNonQuery();
                    if (res > -1) MessageBox.Show("Запись успешно добавлена");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления записи: " + ex.Message);
            }
        }



        public static void UpdateRows(DataGridView dataGridView, string table)
        {
            try
            {
                string keyColumn = dataGridView.Columns[0].Name;
                object keyValue = dataGridView.Rows[0].Cells[0].Value;

                DataTable Table_template = getDataTable(table, " LIMIT 0");
                string sql_com = $"UPDATE {table} SET ";

                
                
                for (int i = 1; i < Table_template.Columns.Count; i++)
                { 
                    string columnName = Table_template.Columns[i].ColumnName;
                    object cellValue = dataGridView.Rows[0].Cells[i].Value;
                    
                    string value = cellValue is string ? $"'{cellValue}'" : cellValue.ToString();
                    sql_com += $"{columnName} = {value}";
                }

                sql_com += $" WHERE {keyColumn} = {keyValue}";


                using (NpgsqlCommand command = _connection.CreateCommand())
                {
                    command.CommandText = sql_com;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка обновления записи: " + ex.Message);
            }
        }


        public static void setGridView(DataTable dataTable, DataGridView dataGridView)
        {
            try
            {
                dataGridView.Columns.Clear();

                if (dataTable == null)
                    throw new Exception("Ошибка чтения таблицы с данными.");

                foreach (DataColumn column in dataTable.Columns)
                {
                    dataGridView.Columns.Add(column.ColumnName, column.ColumnName);
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    int index = dataGridView.Rows.Add();
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        dataGridView.Rows[index].Cells[column.ColumnName].Value = row[column.ColumnName];
                    }
                }

                dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error!\n" + ex.Message);
            }
        }

        public static string getViewByField(string field)
        {
            switch (field) {
                case "_Страна":
                    return "Страны";
                case "_Город":
                    return "Города";
                case "_Должность":
                    return "Должности";
                case "_Статус":
                    return "Статусы";
                case "_Модель":
                    return "МоделиАвто";
                case "_ОтветсвенныйСотрудник":
                    return "Сотрудники";
                case "_ГосНомерАвто":
                    return "Автомобили";
                case "_ИдентификаторСпискаОтгрузки":
                    return "СпискиОтгрузки";
                case "_Клиент":
                    return "Клиенты";
                case "_ИдентификаторАкта":
                    return "АктыВыполненныхРабот";
                case "_ИдентификаторЕдиницыОтгрузки":
                    return "Грузы";
                default:
                    return "";
            }
        }

    }
}
