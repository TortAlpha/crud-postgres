﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8
{
    public partial class CRUDForm : Form
    {

        public CRUDForm()
        {
            InitializeComponent();
            setFullAccessMode();
        }

        public void setFullAccessMode()
        {
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ReadOnly = true;
        }

        public void setReadMode()
        {
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToAddRows = false;
            CreateUpdateButton.Enabled = false;
            DeleteButton.Enabled = false;
            this.Text += " (Read-Only Mode)";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            PostgresModule.setGridView(PostgresModule.getDataTable(comboBox1.Text), dataGridView1);
            comboBox2.Text = "";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            PostgresModule.setGridView(PostgresModule.getDataTable(comboBox2.Text), dataGridView1);
            CreateUpdateButton.Enabled = false;
            DeleteButton.Enabled = false;
            comboBox1.Text = ""; 
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

        private void CreateUpdateButton_Click(object sender, EventArgs e)
        {
            try
            {
                int selected_id = (int)dataGridView1.SelectedRows[0].Cells[0].Value;
                MessageBox.Show(selected_id.ToString());
                CreateUpdateForm createUpdateForm = new CreateUpdateForm(PostgresModule.getDataTable(comboBox1.Text), comboBox1.Text, selected_id);
                createUpdateForm.ShowDialog();
            }
            catch (ArgumentOutOfRangeException ex)
            {
                CreateUpdateForm createUpdateForm = new CreateUpdateForm(PostgresModule.getDataTable(comboBox1.Text), comboBox1.Text, null);
                createUpdateForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.GetType().ToString());
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                PostgresModule.DeleteRows(dataGridView1, comboBox1.Text);
                PostgresModule.setGridView(PostgresModule.getDataTable(comboBox1.Text), dataGridView1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
