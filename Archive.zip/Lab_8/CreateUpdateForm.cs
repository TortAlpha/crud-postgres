﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static Npgsql.Replication.PgOutput.Messages.RelationMessage;

namespace Lab_8
{
    public partial class CreateUpdateForm : Form
    {
        
        List<ViewInfo> viewInfos = new List<ViewInfo>();
        DataTable dataTable1 = new DataTable();
        string SourceView = "";
        bool update = false;

        public CreateUpdateForm(DataTable dataTable, string TableName, int? selected_id)
        {

            InitializeComponent();

            SourceView = TableName;

            dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridView1.ReadOnly = false;
            dataGridView1.Columns.Clear();
            
            dataGridView1.AllowUserToAddRows = true;

            string condition = " LIMIT 0";
            if (selected_id != null)
            {
                update = true;
                condition = $" WHERE {dataTable.Columns[0].ColumnName} = {selected_id}";
            }
            PostgresModule.setGridView(PostgresModule.getDataTable(SourceView, condition), dataGridView1);

            if (update)
            {
                dataGridView1.Rows[0].Cells[0].ReadOnly = true;
            }

            viewInfos.Add(new ViewInfo("cars", "Автомобили"));
            viewInfos.Add(new ViewInfo("acts_of_work_performed", "АктыВыполненныхРабот"));
            viewInfos.Add(new ViewInfo("auto_models", "МоделиАвто"));
            viewInfos.Add(new ViewInfo("cities", "Города"));
            viewInfos.Add(new ViewInfo("clients", "Клиенты"));
            viewInfos.Add(new ViewInfo("countries", "Страны"));
            viewInfos.Add(new ViewInfo("employee_positions", "Должности"));
            viewInfos.Add(new ViewInfo("employees", "Сотрудники"));
            viewInfos.Add(new ViewInfo("orders", "Заказы"));
            viewInfos.Add(new ViewInfo("shipment_lists", "СпискиОтгрузки"));
            viewInfos.Add(new ViewInfo("shipment_units", "Грузы"));
            viewInfos.Add(new ViewInfo("statuses", "Статусы"));
        }


        private void button1_Click(object sender, EventArgs e)
        {
            //отменить
            Close();
            Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //сохранить

            try
            { 
                ViewInfo viewInfo = viewInfos.Find(view => view.ViewName == SourceView);

                if (update)
                {
                    PostgresModule.UpdateRows(dataGridView1, viewInfo.MainTableName);
                }
                else
                {
                    if (viewInfo.MainTableName == "cars")
                    {
                        PostgresModule.InsertRowsWithID(dataGridView1, viewInfo.MainTableName);
                    }
                    else
                    {
                        PostgresModule.InsertRows(dataGridView1, viewInfo.MainTableName);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nОшибка записи");
            }
           

            Close();
            Dispose();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                if (dataGridView1.Columns[e.ColumnIndex].Name[0] == '_')
                {
                    var view = PostgresModule.getViewByField(dataGridView1.Columns[e.ColumnIndex].Name);
                    ChooseForm chooseForm = new ChooseForm(view, e);
                    chooseForm.OnRowSelected += ChooseForm_OnRowSelected;
                    chooseForm.ShowDialog();
                }
            }
        }


        private void ChooseForm_OnRowSelected(string chosen_id, DataGridViewCellEventArgs e)
        {
            dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = chosen_id;
            dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly = true;
        }

    }
}
